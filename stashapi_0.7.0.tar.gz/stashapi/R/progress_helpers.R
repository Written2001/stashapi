new_stash_progress <- function(enabled, total) {
  if (!isTRUE(enabled)) return(NULL)
  utils::txtProgressBar(min = 0, max = total, style = 3)
}

update_stash_progress <- function(progress, value) {
  if (!is.null(progress)) utils::setTxtProgressBar(progress, value)
}

close_stash_progress <- function(progress) {
  if (!is.null(progress)) close(progress)
}

validate_progress_bar <- function(progress_bar) {
  if (!is.logical(progress_bar) || length(progress_bar) != 1L || is.na(progress_bar)) {
    stop("progress_bar must be a single TRUE or FALSE value", call. = FALSE)
  }
  invisible(progress_bar)
}
