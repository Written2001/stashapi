## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, comment = "#>")

## ----dry-run------------------------------------------------------------------
library(stashapi)

updates <- list(
  list(id = "101", title = "First gallery"),
  list(id = "102", title = "Second gallery")
)

plan <- prepare_mutations(
  updates,
  build_input = function(row, index) {
    list(id = row$id, title = row$title)
  },
  operation = "galleryUpdate"
)

plan$entries[[1]]$input
plan$entries[[1]]$target

## ----preview------------------------------------------------------------------
preview <- execute_mutations(
  plan,
  mutate = function(input) stop("this must not run during a dry run"),
  progress = FALSE
)

preview$dry_run
vapply(preview$results, function(entry) entry$status, character(1))

## ----query-result-shape-------------------------------------------------------
galleries <- data.frame(
  id = c("201", "202"),
  title = c("Example gallery A", "Example gallery B"),
  date = c("2026-01-01", NA_character_),
  stringsAsFactors = FALSE
)

plan <- prepare_mutations(
  galleries,
  build_input = function(row, index) {
    list(id = row$id, title = row$title, date = row$date)
  },
  operation = "galleryUpdate"
)

plan$entries[[2]]$input
plan$entries[[2]]$omitted

## ----missing-values-----------------------------------------------------------
plan <- prepare_mutations(
  list(list(id = "301")),
  build_input = function(row, index) {
    list(
      id = row$id,
      title = NA_character_,
      details = NULL,
      tag_ids = list(ids = c("41", NA_character_), mode = "ADD")
    )
  }
)

plan$entries[[1]]$input
plan$entries[[1]]$omitted

## ----strict-values, error=TRUE------------------------------------------------
try({
prepare_mutations(
  list(list(id = "302")),
  function(row, index) list(id = row$id, title = NA_character_),
  na = "error"
)
})

## ----nested-modes-------------------------------------------------------------
source <- list(
  list(
    ids = c("401", "402"),
    performer_ids = c("51", NA_character_),
    urls = "https://example.test/gallery/one"
  )
)

plan <- prepare_mutations(
  source,
  build_input = function(row, index) {
    list(
      ids = row$ids,
      organized = TRUE,
      performer_ids = list(ids = row$performer_ids, mode = "ADD"),
      urls = list(values = row$urls, mode = "SET")
    )
  },
  operation = "bulkImageUpdate"
)

plan$entries[[1]]$input$performer_ids
plan$entries[[1]]$input$urls

## ----live-execution, eval=FALSE-----------------------------------------------
# result <- execute_mutations(
#   plan,
#   mutate = stashapi::galleryUpdate,
#   dry_run = FALSE,
#   on_error = "continue"
# )

## ----failures-----------------------------------------------------------------
mutate <- function(input) {
  if (identical(input$id, "102")) stop("example validation failure")
  list(id = input$id, updated = TRUE)
}

result <- execute_mutations(
  plan = prepare_mutations(
    list(list(id = "101"), list(id = "102"), list(id = "103")),
    function(row, index) list(id = row$id)
  ),
  mutate = mutate,
  dry_run = FALSE,
  on_error = "continue",
  progress = FALSE
)

vapply(result$results, function(entry) entry$index, integer(1))
vapply(result$results, function(entry) entry$status, character(1))
result$results[[2]]$error$message

## ----bulk-plan----------------------------------------------------------------
bulk_source <- list(
  list(
    ids = c("601", "602"),
    studio_id = "7",
    performer_ids = c("51", "52"),
    urls = "https://example.test/gallery/one",
    date = "2026-01-01"
  ),
  list(
    ids = "603",
    studio_id = "7",
    performer_ids = character(),
    urls = "https://example.test/gallery/two",
    date = NA_character_
  )
)

bulk_plan <- prepare_mutations(
  bulk_source,
  build_input = function(row, index) {
    list(
      ids = row$ids,
      organized = TRUE,
      urls = list(values = row$urls, mode = "SET"),
      studio_id = row$studio_id,
      performer_ids = list(ids = row$performer_ids, mode = "ADD"),
      date = row$date
    )
  },
  operation = "bulkImageUpdate"
)

bulk_plan$entries[[1]]$input

## ----bulk-execution, eval=FALSE-----------------------------------------------
# execute_mutations(bulk_plan, stashapi::bulkImageUpdate, progress = FALSE)
# 
# bulk_result <- execute_mutations(
#   bulk_plan,
#   stashapi::bulkImageUpdate,
#   dry_run = FALSE,
#   on_error = "continue"
# )

